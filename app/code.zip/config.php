<?php
session_start();
error_reporting(E_ALL & ~E_NOTICE);
$servername = "localhost";
$username = "root";
$password = "Imysql74!";
$dbname = "smomscic_tqf";
?> 