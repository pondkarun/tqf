

<?php 
include("header.php");
include("leftmenu.php");
$id = $_GET['id'];
if($id>0 && $id!=''){
$sql = "SELECT s.* FROM dbcourse_add s WHERE s.id = '".$id."' ";
$result = $conn->query($sql);
$row = $result->fetch_array();
}
?>
<script  type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
<script  type="text/javascript"> 
$(document).ready(function(){
  $("#submit_bnt").click(function(){ 
      var Coursecode = $("#Coursecode").val();
      if(Coursecode==''){
        alert("กรุณากรอกรหัสวิชา");
      }else{
        $("#frm_save").submit();
      }
  });
});
</script>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-12">
            <h1> <?php if($id==''){?>เพิ่ม <?php }else{?>แก้ไข <?php } ?>ข้อมูลรายวิชา (สำหรับทดสอบออนไลน์ Mainacup.com)</h1>
          </div>
        
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-8">
            <!-- general form elements -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title"><?php if($id==''){?>เพิ่ม <?php }else{?>แก้ไข <?php } ?>ข้อมูลรายวิชา</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form role="form" id="frm_save" action="add_db.php" method="POST" enctype="multipart/form-data"> 
                <input type="hidden" id="hid_id_edit" name="hid_id_edit" value="<?php echo $id;?>">
                <input type="hidden" id="hid_save" name="hid_save" value="1">
                <div class="card-body">
                  <div class="form-group">
                    <label for="exampleInputEmail1">รหัสวิชา</label>
                    <input class="form-control" value="<?php echo $row['Coursecode'];?>" type="text" name="Coursecode" id="Coursecode" placeholder="รหัสวิชา">
                  </div>
                
                  <div class="form-group">
                    <label for="exampleInputEmail1">ชื่อภาษาไทย</label>
                    <input class="form-control" value="<?php echo $row['Thaisubjectname'];?>" type="text" name="Thaisubjectname" id="Thaisubjectname" placeholder="ชื่อภาษาไทย">
                  </div>


                  <div class="form-group">
                    <label for="exampleInputEmail1">ชื่อภาษาอังกฤษ</label>
                    <input class="form-control" value="<?php echo $row['Englishsubjectname'];?>" type="text" name="Englishsubjectname" id="Englishsubjectname" placeholder="ชื่อภาษาไทย">
                  </div>


                  <div class="form-group">
                    <label for="exampleInputEmail1">หลักสูตรและประเภทรายวิชา</label>
                    <input class="form-control" value="<?php echo $row['Curriculumandcoursetype'];?>" type="text" name="Curriculumandcoursetype" id="Curriculumandcoursetype" placeholder="หลักสูตรและประเภทรายวิชา">
                  </div>


                  <div class="form-group">
                    <label for="exampleInputEmail1">หน่วยกิต</label>
                    <input class="form-control" value="<?php echo $row['credit'];?>" type="text" name="credit" id="credit" placeholder="หน่วยกิต">
                  </div>


                  <div class="form-group">
                    <label for="exampleInputEmail1">อาจารย์ผู้รับผิดชอบ</label>
                    <input class="form-control" value="<?php echo $row['nameteacher'];?>" type="text" name="nameteacher" id="nameteacher" placeholder="อาจารย์ผู้รับผิดชอบ">
                  </div>
                 
                </div>
                <!-- /.card-body -->

                <div class="card-footer">

                  <button type="button" id="submit_bnt" class="btn btn-primary"><?php if($id==''){?>บันทึก<?php }else{?>แก้ไข<?php } ?>ข้อมูล</button>
                </div>
              </form>
            </div>
            <!-- /.card -->

            

            
           

          </div>
          <!--/.col (left) -->
          
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>

  <!-- jQuery -->
<script src="template/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="template/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- bs-custom-file-input -->
<script src="template/plugins/bs-custom-file-input/bs-custom-file-input.min.js"></script>
<!-- AdminLTE App -->
<script src="template/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="template/dist/js/demo.js"></script>
<script type="text/javascript">
$(document).ready(function () {
  bsCustomFileInput.init();
});
</script>


  <?php 
include("footer.php");
?>