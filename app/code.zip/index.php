<?php
include("header.php");
include("leftmenu.php");
?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-12">
            <h1>ข้อมูลรายวิชา (สำหรับทดสอบออนไลน์ Mainacup.com)</h1>
          </div>
          
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                
                <form  id="frm_save" action="table.php" 
                  method="POST"> 
                  <input type="hidden" id="hid_search" name="hid_search" value="1">
                <div class="card-tools">
                 <!--< <div class="input-group input-group-sm" style="width: 300px;">

                    input type="text" id="table_search" name="table_search" 
                           class="form-control float-right" placeholder="Search">

                    <div class="input-group-append">
                      <button type="submit" class="btn btn-default"><i class="fas fa-search"></i></button>

                  
                    </div>
                  </div>--></form>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table class="table table-bordered">
                  <thead>                  
                    <tr>
                      <th width="1%" style="width: 10px">#</th>
                      <th width="14%">รหัสวิชา</th>
                      <th width="15%">ชื่อภาษาไทย</th>
                      <th width="15%">ชื่อภาษาอังกฤษ</th>
                      <th width="20%">หลักสูตรและประเภทรายวิชา</th>
                      <th width="10%">หน่วยกิต</th>
                      <th width="15%">อาจารย์ผู้รับผิดชอบ</th>
                      <th width="10%" style="width: 40px"><div align="center">แก้ไข</div></th>
                    </tr>
                  </thead>
                  <tbody>

                  <?php                 
                  $hid_search = $_POST['hid_search'];
                  $table_search = $_POST['table_search'];
                  if($hid_search == 1 AND trim($table_search)!=''){
                    //$where .=  " AND x.software_name LIKE '%".$table_search."%' "; 
                  }
                  $sql = "SELECT s.*  
                                                FROM dbcourse_add s 
                                                WHERE 1=1 ".$where."
                                         ";
                                        $result = $conn->query($sql);
                                        $no = 0;
                                        while ($row = $result->fetch_assoc()) {
                                          $no++;
?>
                    <tr>
                      <td><?php echo $no;?>.</td>
                      <td><?php echo $row['Coursecode']?>
                      </td>
                      
                      <td><div align="left">
                       
                       <?php echo $row['Thaisubjectname']?>
                    
                        </div></td>
                        <td><div align="left">
                       
                       <?php echo $row['Englishsubjectname']?>
                    
                        </div></td>
                        <td><div align="left">
                       
                       <?php echo $row['Curriculumandcoursetype']?>
                    
                        </div></td>
                        <td><div align="left">
                       
                       <?php echo $row['credit']?>
                    
                        </div></td>
                        
                        <td><div align="left">
                        <?php echo $row['nameteacher']?>
                       
                        </div></td>

                        <td><div align="left">
                       
                        <a href="form.php?id=<?php echo $row['id']?>">แก้ไข</a>
                        
                       </div></td>
                        
                   
                       
                    </tr>
                                        <?php } ?> 
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
              <!--<div class="card-footer clearfix">
                <ul class="pagination pagination-sm m-0 float-right">
                  <li class="page-item"><a class="page-link" href="#">&laquo;</a></li>
                  <li class="page-item"><a class="page-link" href="#">1</a></li>
                  <li class="page-item"><a class="page-link" href="#">2</a></li>
                  <li class="page-item"><a class="page-link" href="#">3</a></li>
                  <li class="page-item"><a class="page-link" href="#">&raquo;</a></li>
                </ul>-->
              </div>
            </div>
            <!-- /.card -->


            
       
        
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <?php 
include("footer.php");

?>